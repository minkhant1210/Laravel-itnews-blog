<h4>Welcome</h4>
<a href="<?php echo e(route('login')); ?>">Login</a>
<?php /**PATH C:\Users\user\Desktop\Laravel\laravel7\resources\views/welcome.blade.php ENDPATH**/ ?>