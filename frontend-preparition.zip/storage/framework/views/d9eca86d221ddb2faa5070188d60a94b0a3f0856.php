<li class="menu-item">
    <a href="<?php echo e($link); ?>" class="menu-item-link <?php echo e($link === Request::url() ? 'active' : ''); ?>">
        <span class="text-capitalize">
            <i class="<?php echo e($class); ?> mr-1"></i>
            <?php echo e($name); ?>

        </span>
        <span class="badge badge-pill bg-white shadow-sm text-primary"><?php echo e($counter); ?></span>
    </a>
</li>
<?php /**PATH C:\Users\user\Desktop\Laravel\laravel7\resources\views/components/menu-list.blade.php ENDPATH**/ ?>