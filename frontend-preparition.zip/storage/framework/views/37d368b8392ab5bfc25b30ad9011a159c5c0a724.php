<li class="menu-spacer"></li>
<?php /**PATH C:\Users\user\Desktop\Laravel\laravel7\resources\views/components/menu-spacer.blade.php ENDPATH**/ ?>