<div class="col-12 col-lg-3 col-xl-2 vh-100 sidebar">
    <div class="d-flex justify-content-between align-items-center py-2 mt-3 nav-brand">
        <div class="d-flex align-items-center">
                    <span class="bg-primary p-2 rounded d-flex justify-content-center align-items-center mr-2">
                        <i class="feather-shopping-bag text-white h4 mb-0"></i>
                    </span>
            <span class="font-weight-bolder h4 mb-0 text-uppercase text-primary">My Shop</span>
        </div>
        <button class="hide-sidebar-btn btn btn-light d-block d-lg-none">
            <i class="feather-x text-primary" style="font-size: 2em;"></i>
        </button>
    </div>
    <div class="nav-menu">
        <ul>
            <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuList::class, ['name' => 'Home','link' => ''.e(route('home')).'','class' => 'feather-home']); ?>
<?php $component->withName('menu-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56)): ?>
<?php $component = $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56; ?>
<?php unset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'Menu test']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuList::class, ['name' => 'Add Item','link' => ''.e(route('home')).'','class' => 'feather-plus-circle']); ?>
<?php $component->withName('menu-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56)): ?>
<?php $component = $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56; ?>
<?php unset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuList::class, ['name' => 'Item list','link' => ''.e(route('home')).'','class' => 'feather-list','counter' => '10']); ?>
<?php $component->withName('menu-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56)): ?>
<?php $component = $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56; ?>
<?php unset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuTitle::class, ['title' => 'User Profile']); ?>
<?php $component->withName('menu-title'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0)): ?>
<?php $component = $__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0; ?>
<?php unset($__componentOriginal350ed2e633449e76a1b03b15ee6357cd8ee77be0); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuList::class, ['name' => 'Your Profile','link' => ''.e(route('profile')).'','class' => 'feather-user']); ?>
<?php $component->withName('menu-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56)): ?>
<?php $component = $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56; ?>
<?php unset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuList::class, ['name' => 'Change Password','link' => ''.e(route('profile.edit.password')).'','class' => 'feather-refresh-cw']); ?>
<?php $component->withName('menu-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56)): ?>
<?php $component = $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56; ?>
<?php unset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuList::class, ['name' => 'Update Profile','link' => ''.e(route('profile.edit.name.email')).'','class' => 'feather-message-square']); ?>
<?php $component->withName('menu-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56)): ?>
<?php $component = $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56; ?>
<?php unset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuList::class, ['name' => 'Update photo','link' => ''.e(route('profile.edit.photo')).'','class' => 'feather-image']); ?>
<?php $component->withName('menu-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56)): ?>
<?php $component = $__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56; ?>
<?php unset($__componentOriginal76f79590a674cca8f416eaff939fec93ea04ee56); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenuSpacer::class, []); ?>
<?php $component->withName('menu-spacer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f)): ?>
<?php $component = $__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f; ?>
<?php unset($__componentOriginal9e9fbe2fe272163d578bb7244fe0a9da9d31798f); ?>
<?php endif; ?>
            <li class="menu-item">
                <a class="btn btn-outline-primary btn-block" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                    <?php echo e(__('Logout')); ?>

                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>


        </ul>
    </div>
</div>
<?php /**PATH C:\Users\user\Desktop\Laravel\laravel7\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>