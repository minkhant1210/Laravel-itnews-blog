<li class="menu-title">
    <span><?php echo e($title); ?></span>
</li>
<?php /**PATH C:\Users\user\Desktop\Laravel\laravel7\resources\views/components/menu-title.blade.php ENDPATH**/ ?>