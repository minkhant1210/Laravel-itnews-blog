<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::prefix('profile')->group(function (){
    Route::get('/',[ProfileController::class,'profile'])->name('profile');

    Route::get('edit-photo',[ProfileController::class,'editPhoto'])->name('profile.edit.photo');
    Route::post('/change-photo',[ProfileController::class,'changePhoto'])->name('profile.changePhoto');

    Route::get('/edit-password',[ProfileController::class,'editPassword'])->name('profile.edit.password');
    Route::post('/change-password',[ProfileController::class,'changePassword'])->name('profile.changePassword');

    Route::get('/edit-name-and-email',[ProfileController::class,'editNameEmail'])->name('profile.edit.name.email');
    Route::post('/change-name',[ProfileController::class,'changeName'])->name('profile.changeName');
    Route::post('/change-email',[ProfileController::class,'changeEmail'])->name('profile.changeEmail');
});
